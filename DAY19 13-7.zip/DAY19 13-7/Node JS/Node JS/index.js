console.log ("Hello Welcome to my first node project");
const os=require('./second');
console.log("Hello World",obj);