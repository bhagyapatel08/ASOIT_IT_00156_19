function funct1(){
    console.log("this is ecmascript modules,funct1!!");
}

function funct2(){
    console.log("this is ecmascript modules,funct2!");
}

export{funct1}