const path=require('path');
const a1=path.basename('"C:\Users\Anjali Patadiya\Desktop\College"')
console.log(a1);

// const a2=path.extname('__filename');
// console.log(__filename,a2);

const a3=path.dirname('"C:\Users\Anjali Patadiya\Desktop\College"');
console.log(a3);