const EventEmitter=require('events');

class MyEmitter extends EventEmitter{};

const myEmitter = new MyEmitter();

myEmitter.on('waterfull',()=>{
    console.log("Please turn off the motor!");
    setTimeout(()=>{
        console.log("please turn off the motor! it's a gental remainder");
    },3000);
})
console.log("the script is runnig");
myEmitter.emit('waterfull');